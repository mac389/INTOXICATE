# TikZPoster 24 x 36 Template

This is a `tikzposter`-class version of the uploaded 24 x 36 inch poster template.

Compile with:

```bash
pdflatex poster_template_24x36_tikzposter.tex
```

Notes:
- The page is set to 24 x 36 inches using `\geometry` after loading `tikzposter`.
- The layout uses a `scope` with `x=1in,y=1in`; coordinates are translated so the poster's top-left corner is `(-12,18)`.
- The Weill Cornell Emergency Medicine logo is stored in `assets/` and can be replaced.
- Helvetica is used for portability; the PowerPoint template appears to use an Arial Narrow-like font.
